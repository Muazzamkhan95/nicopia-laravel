<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use App\Models\Project;
use App\Models\Timeline;
use App\Models\VideoGallery;
use Illuminate\Http\Request;
use Illuminate\Http\UploadedFile;

class ProjectController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $projects = Project::all();
        return view('admin.project.index', compact('projects'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        $blogs = Blog::all();
        return view('admin.project.create', compact('blogs'));
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        // dd($request->all());
        $project = new Project();
        $project->name = $request->name;
        $project->line_of_business = $request->line_of_business;
        $project->types_of_project = $request->types_of_project;
        $project->region = $request->region;
        $project->description = $request->description;
        $project->enabledVideo = $request->enabledVideo;
        $project->enabledTimleline = $request->enabledTimleline;
        $project->timeline_name = $request->timeline_name;
        $project->timeline_desciption = $request->timeline_desciption;

        if (!empty(request()->file('image'))) {
            $destinationPath = 'storage/images';
            $extension = request()->file('image')->getClientOriginalExtension();
            $fileName = '/storage/images/' . 'pi-' . time() . rand() . '.' . $extension;
            request()->file('image')->move($destinationPath, $fileName);
            $project->image = $fileName;
        }
        $project->save();
        // dd($project);
        if ($project->enabledVideo == 1) {
            $videoDataArray = json_decode($request->input('videoDataArray'), true);
            foreach ($videoDataArray as $vd) {
                // dd($vd);
                $video_gallery = new VideoGallery();
                $video_gallery->name = $vd['title'];
                $video_gallery->description = $vd['description'];
                $video_gallery->url = $vd['url'];
                $video_gallery->project_id = $project->id;
                $video_gallery->banner = $vd['banner'];
                $video_gallery->save();
            }
        }
        if ($project->enabledTimleline == 1) {

            $timelineItem = json_decode($request->input('timelineItem'), true);
            foreach ($timelineItem as $ti) {

                $timeline = new Timeline();
                $timeline->year = $ti['year'];
                $timeline->project_id = $project->id;
                $timeline->save();
                $timeline->blogs()->attach($ti['blogs']);
            }
        }
        // dd($);
        return response('Successfuly Add Project', 200);
    }

    /**
     * Display the specified resource.
     */
    public function show(Project $project)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(Project $project)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Project $project)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Project $project)
    {
        if ($project->enabledVideo == 1) {
            // dd($project->id);
            $video_gallery = VideoGallery::where('project_id', $project->id)->firstOrFail();
            $video_gallery->delete();
        }
        if ($project->enabledTimleline == 1) {
            $timeline = Timeline::where('project_id', $project->id)->firstOrFail();
            $timeline->blogs()->detach();
            $timeline->delete();
        }
        $project->delete();

        return redirect()->route('projects.index')->with('success', 'Project deleted successfully.');
    }
}
