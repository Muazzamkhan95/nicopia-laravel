<?php

namespace App\Http\Controllers;

use App\Models\Blog;
use App\Models\Project;
use App\Models\SectionSetting;
use App\Models\Service;
use App\Models\Slider;
use App\Models\Team;
use App\Models\Testimonial;
use Illuminate\Http\Request;

class FrontendController extends Controller
{

    public function index()
    {
        $Offers = SectionSetting::where('name', '=', 'Offer')->first();
        $Clients = SectionSetting::where('name', '=', 'Clients')->first();
        $Recent = SectionSetting::where('name', '=', 'Recent Project')->first();
        $About = SectionSetting::where('name', '=', 'About')->first();
        // dd($Clients);
        $sliders = Slider::all();
        $services = Service::all();
        $projects = Project::all();
        $testimonials = Testimonial::all();
        $blogs = Blog::limit('4')->get();
        // dd($blogs);
        return view('frontend.home', compact('Offers', 'Clients', 'Recent', 'About', 'sliders', 'services', 'projects', 'testimonials', 'blogs'));
    }
    public function blog()
    {
        $blogs = Blog::paginate(15);
        // dd($blogs);
        return view('frontend.blog', compact('blogs'));
    }
    public function singleBlog($slug)
    {
        $blogs = Blog::limit(2)->get();
        $blog = Blog::where('slug', $slug)->firstOrFail();

        return view('frontend.blog.single-blog', ['blog' => $blog, 'blogs' => $blogs]);
    }
    public function projects()
    {
        $teams = Team::paginate(4);

        $Team = SectionSetting::where('name', '=', 'Team')->first();

        $projects = Project::paginate(15);
        // dd($blogs);
        return view('frontend.projects', compact('projects', 'teams', 'Team'));
    }
    public function singleProject($slug)
    {
        $projects = Project::limit(2)->get();
        // $project = Project::with('videoGalleries')->with('timelineItems')->where('slug', $slug)->firstOrFail();
        $project = Project::with(['videoGalleries', 'timelines.blogs'])
            ->where('slug', $slug)->firstOrFail();
        // dd($project);
        // $blogs = [];
        // foreach ($project->timelineItems as $vs) {
        //     dd($vs->blogTimeline);
        //     $blog = Blog::where('id', $vs->blogTimeline->blog_id);
        //     array_push($blogs, $blog);
        // }
        // dd($blogs);
        return view('frontend.project.single-project', ['project' => $project, 'projects' => $projects]);
    }
    public function services()
    {
        $Clients = SectionSetting::where('name', '=', 'Clients')->first();

        $services = Service::paginate(15);
        $testimonials = Testimonial::paginate(15);
        // dd($blogs);
        return view('frontend.services', compact('services', 'testimonials', 'Clients'));
    }
    public function about()
    {
        $teams = Team::paginate(4);
        $About = SectionSetting::where('name', '=', 'About')->first();

        $Team = SectionSetting::where('name', '=', 'Team')->first();
        return view('frontend.about', compact('teams', 'Team', 'About'));
    }
}
